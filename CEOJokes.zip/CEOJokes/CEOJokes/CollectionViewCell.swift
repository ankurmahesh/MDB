//
//  CollectionViewCell.swift
//  CEOJokes
//
//  Created by Mudit Mittal on 2/23/16.
//  Copyright © 2016 Mudit Mittal. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var ceoImage: UIImageView!
    @IBOutlet weak var jokeLabel: UILabel!


}
