//
//  ViewController.swift
//  Spotlight
//
//  Created by Ankur Mahesh on 2/18/16.
//  Copyright © 2016 Ankur Mahesh. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func turnOn(sender: AnyObject) {
        
        let avDevice = AVCaptureDevice.defaultDeviceWithMediaType(AVMediaTypeVideo)
        do {
            try avDevice.lockForConfiguration()
        }
        catch {
            print("error")
        }
        if avDevice.hasTorch {
            avDevice.torchMode = AVCaptureTorchMode.On
            
        }
        else {
            print("error")
        }
        do {
            try avDevice.unlockForConfiguration()
        }
        catch {
            print("error")
        }
    }

    @IBAction func turnOff(sender: AnyObject) {
        let avDevice = AVCaptureDevice.defaultDeviceWithMediaType(AVMediaTypeVideo)
        do {
            try avDevice.lockForConfiguration()
        }
        catch {
            print("error")
        }
        if avDevice.hasTorch {
                avDevice.torchMode = AVCaptureTorchMode.Off
        }
        else {
            print("error")
        }
        do {
            try avDevice.unlockForConfiguration()
        }
        catch {
            print("error")
        }
    }
}

